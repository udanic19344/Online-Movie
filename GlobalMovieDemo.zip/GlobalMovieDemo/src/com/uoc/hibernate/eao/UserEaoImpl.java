/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Base;
import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.User;
import com.uoc.hibernate.util.HibernateUtil;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Admin
 */
public class UserEaoImpl implements UserEao{
    SessionFactory sessionFactory;

    public UserEaoImpl() {
        sessionFactory = HibernateUtil.getSessFactory();
        
    }
    
    
    

    @Override
    public void create(User user) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        Base base = new Base();
        base.setCreatedBy("Udani");
        base.setCreatedDate(new Date());
        user.setBase(base);
        
        session.persist(user);
        
 
        
        
        session.getTransaction().commit();
        session.close();
        
        
                
        
    }

    @Override
    public void saveOrUpdate(User user) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        Base base = new Base();
        base.setCreatedBy("Chethana");
        base.setCreatedDate(new Date());
        user.setBase(base);
        
        session.saveOrUpdate(user);
        
        session.getTransaction().commit();
        session.close();
        
        
        
    }

    @Override
    public void delete(User user) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        Base base = new Base();
        base.setCreatedBy("Udani");
        base.setCreatedDate(new Date());
        user.setBase(base);
        
        session.delete(user);
        
 
        
        
        session.getTransaction().commit();
        session.close();
        
        
               
        
        
    

   
    }

    @Override
    public User getUser(String U_ID) {
        Session session = sessionFactory.getCurrentSession();
        User user = (User)  session.get(User.class, U_ID);
        List<Movie> movies = user.getMovies();
        
    session.close();
    return user;
    
    
    }

    @Override
    public boolean uvalidate(String U_Name, String U_Pass) {
          // session1.beginTransaction();
        boolean check = false;
        User user;
        Session session1 = sessionFactory.openSession();
        String hql = "FROM User where U_Name=:U_Name ";
        Query query = session1.createQuery(hql);
        query.setParameter("U_Name", U_Name);
        User usser = (User) query.uniqueResult();
        
        user = (User) session1.get(User.class, usser.getU_ID());
        
        
        //System.out.println(usser.getuName());
        //System.out.println(usser.getuPass());
        if (user != null && user.getU_Pass().equals(U_Pass)){
            check = true;
            System.out.println("This is a your user ID  : "+user.getU_ID());
            System.out.println("Loging Successful...!!!!");
            return true;
        }else{
            System.out.println("Loging Failed...Try Again... ");
            return(false);
        }
        
    }

    @Override
    public List<User> getAllUser(User user) {
        String hql = "FROM User"; 
        Session session = sessionFactory.openSession(); 

        
        org.hibernate.Query query = session.createQuery(hql); 
 
        
        List<User> users = query.list(); 
        
        session.close();
        
        return users; 
    
    
    
    }

  
    
    
    }

