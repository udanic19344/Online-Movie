/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.Review;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface MovieEao {
    void crete(Movie mov);
    void saveOrUpdate(Movie mov);
    Movie getMovie(String M_ID);

    List<Movie> getAllMovie(Movie mov);

    public void delete(Movie mv);
    
    void buyMovie(String M_ID,int U_ID);
    
    List<Movie> getMoviesByUser(int U_ID);
    
    
    
    
    
    
    
}
