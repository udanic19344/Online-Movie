/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Gener;
import com.uoc.hibernate.entity.Movie;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface GenerEao {
    void create(Gener gen);
    
    
     void saveOrUpdate(Gener gen);
 
     Gener getGenre(String G_ID) ;
     List<Gener> getAllGener(Gener gen);
    
}
