/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "GMDB_MOVIE_TABLE")
public class Movie implements Serializable {
    private String M_ID;
    private String M_Name;
    private String M_Actors;
    private String M_Directors;
    private int M_Runtime;
    private int M_AverageRate;

    private Admin admin;
    private List<Review> reviews;
    private List<User> users = new ArrayList<>() ;
    private List<Gener> geners = new ArrayList<>();
    
    
    public Movie() {
   
    }

    public Movie(String M_ID, String M_Name, String M_Actors, String M_Directors, int M_Runtime) {
        this.M_ID = M_ID;
        this.M_Name = M_Name;
        this.M_Actors = M_Actors;
        this.M_Directors = M_Directors;
        this.M_Runtime = M_Runtime;
    }

    @Id
    public String getM_ID() {
        return M_ID;
    }

    public void setM_ID(String M_ID) {
        this.M_ID = M_ID;
    }

    public String getM_Name() {
        return M_Name;
    }

    public void setM_Name(String M_Name) {
        this.M_Name = M_Name;
    }

    public String getM_Actors() {
        return M_Actors;
    }

    public void setM_Actors(String M_Actors) {
        this.M_Actors = M_Actors;
    }

    public String getM_Directors() {
        return M_Directors;
    }

    public void setM_Directors(String M_Directors) {
        this.M_Directors = M_Directors;
    }

    public int getM_Runtime() {
        return M_Runtime;
    }

    public void setM_Runtime(int M_Runtime) {
        this.M_Runtime = M_Runtime;
    }

    @Transient
    public int getM_AverageRate() {
        return M_AverageRate;
    }

    public void setM_AverageRate(int M_AverageRate) {
        this.M_AverageRate = M_AverageRate;
    }

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Ad_ID")
    public Admin getAdmin() {
        return admin;
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    @OneToMany(mappedBy = "movie")
    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "GMDB_USER_MOVIE_TABLE",
                joinColumns = {@JoinColumn(name = "M_ID")},
                inverseJoinColumns = {@JoinColumn(name ="U_ID")})
    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    @ManyToMany(cascade = CascadeType.ALL)
     @JoinTable(name = "GMDB_MOVIE_GENRE_TABLE",
               joinColumns = {@JoinColumn(name = "M_ID")},
               inverseJoinColumns = {@JoinColumn(name = "G_ID")})
    public List<Gener> getGeners() {
        return geners;
    }

    public void setGeners(List<Gener> geners) {
        this.geners = geners;
    }
    
    
    
}
