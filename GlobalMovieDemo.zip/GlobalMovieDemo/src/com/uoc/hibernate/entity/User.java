/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "GMDB_USER_TABLE")
public class User implements Serializable {
    private int U_ID;
    private String U_Name;
    private String U_Email;
    private String U_Pass;
    private Base base;

    
    private List<Movie> movies = new ArrayList<>();
    private List<Review> reviews;
    
    
    
//    public User() {
//    }
//
//    
//    }
//
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    public String getU_ID() {
//        return U_ID;
//    }
//
//    public void setU_ID(String U_ID) {
//        this.U_ID = U_ID;
//    }
//
// 
//
//    public String getU_Name() {
//        return U_Name;
//    }
//
//    public void setU_Name(String U_Name) {
//        this.U_Name = U_Name;
//    }
//
//    public String getU_Email() {
//        return U_Email;
//    }
//
//    public void setU_Email(String U_Email) {
//        this.U_Email = U_Email;
//    }
//
//    public String getU_Pass() {
//        return U_Pass;
//    }
//
//    public void setU_Pass(String U_Pass) {
//        this.U_Pass = U_Pass;
//    }
//
//    @ManyToMany(cascade = CascadeType.ALL)
//    @JoinTable(name = "GMDB_USER_MOVIE_TABLE",
//                joinColumns = {@JoinColumn(name = "U_ID")},
//                inverseJoinColumns = {@JoinColumn(name = "M_ID")})
//    
//    public List<Movie> getMovies() {
//        return movies;
//    }
//
//    public void setMovies(List<Movie> movies) {
//        this.movies = movies;
//    }
//
//    @OneToMany(mappedBy = "user")
//    public List<Review> getReviews() {
//        return reviews;
//    }
//
//    public void setReviews(List<Review> reviews) {
//        this.reviews = reviews;
//    }
//    
//    
//    @Embedded
//    public Base getBase(){
//        return base;
//        
//    }
//
//    public void setBase(Base base) {
//        this.base = base;
//    }

    public User() {
    }

    public User(String U_Name, String U_Email, String U_Pass) {
        this.U_Name = U_Name;
        this.U_Email = U_Email;
        this.U_Pass = U_Pass;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getU_ID() {
        return U_ID;
    }

    public void setU_ID(int U_ID) {
        this.U_ID = U_ID;
    }

    public String getU_Name() {
        return U_Name;
    }

    public void setU_Name(String U_Name) {
        this.U_Name = U_Name;
    }

    public String getU_Email() {
        return U_Email;
    }

    public void setU_Email(String U_Email) {
        this.U_Email = U_Email;
    }

    public String getU_Pass() {
        return U_Pass;
    }

    public void setU_Pass(String U_Pass) {
        this.U_Pass = U_Pass;
    }

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "GMDB_USER_MOVIE_TABLE",
                joinColumns = {@JoinColumn(name = "U_ID")},
                inverseJoinColumns = {@JoinColumn(name = "M_ID")})
    
    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    @OneToMany(mappedBy = "user")
    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @Embedded
    public Base getBase() {
        return base;
    }

    public void setBase(Base base) {
        this.base = base;
    }
    
    
}
