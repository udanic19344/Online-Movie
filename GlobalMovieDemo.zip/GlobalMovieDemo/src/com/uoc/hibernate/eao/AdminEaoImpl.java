/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Admin;
import com.uoc.hibernate.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Admin
 */
public class AdminEaoImpl implements AdminEao{
    SessionFactory sessionFactory;

    public AdminEaoImpl() {
        sessionFactory = HibernateUtil.getSessFactory();
        
    }
    
   
    @Override
    public void create(Admin ad) {
         Session session = sessionFactory.openSession();
         session.beginTransaction();
         
         session.persist(ad);
         
         session.getTransaction().commit();
         session.close();
         
    
    }

    @Override
    public Admin getAdmin(String Ad_ID) {
        Session session =sessionFactory.openSession();
        Admin admin = (Admin) session.get(Admin.class, Ad_ID);
        
    session.close();
    return admin;
    
    }
    
    
}
