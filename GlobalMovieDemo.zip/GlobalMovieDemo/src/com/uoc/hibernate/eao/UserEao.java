
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.User;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface UserEao {
    
    void create(User user);
    
    void  saveOrUpdate(User user);
    
    void  delete(User user);
    
    User getUser(String U_ID);
    
    boolean uvalidate(String U_Name, String U_Pass);
    
    List<User> getAllUser(User user);
    
    
    
    
    
    
    
}
