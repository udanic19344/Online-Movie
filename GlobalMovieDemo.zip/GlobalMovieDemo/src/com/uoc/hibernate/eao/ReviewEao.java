/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Review;

/**
 *
 * @author Admin
 */
public interface ReviewEao {
    void createReview(Review rate, int U_ID,String M_ID  );
    
    
    
}
