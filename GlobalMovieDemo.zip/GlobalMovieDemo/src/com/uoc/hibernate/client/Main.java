/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.client;

import com.uoc.hibernate.eao.AdminEao;
import com.uoc.hibernate.eao.AdminEaoImpl;
import com.uoc.hibernate.eao.GenerEao;
import com.uoc.hibernate.eao.GenerEaoImpl;
import com.uoc.hibernate.eao.MovieEao;
import com.uoc.hibernate.eao.MovieEaoImpl;
import com.uoc.hibernate.eao.ReviewEao;
import com.uoc.hibernate.eao.ReviewEaoImpl;
import com.uoc.hibernate.eao.UserEao;
import com.uoc.hibernate.eao.UserEaoImpl;
import com.uoc.hibernate.entity.Admin;
import com.uoc.hibernate.entity.Gener;
import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.Review;
import com.uoc.hibernate.entity.User;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {

      
            Scanner reader = new  Scanner(System.in);
           
            
            // Create instances of EAO classes. 
            
            AdminEao adEao = new AdminEaoImpl();
            MovieEao movEao = new MovieEaoImpl();
            UserEao userEao = new UserEaoImpl();
            GenerEao generEao = new GenerEaoImpl();
            ReviewEao reviewEao = new  ReviewEaoImpl();
            
            
            
            Admin ad1 = new Admin("Ad1","Udani","udani");
        
            Admin ad2 = new Admin("Ad2","Chethana","chethana");
            
            
            Gener gen1 = new  Gener("G1","Romance");
            Gener gen2 = new  Gener("G2","Action");
            Gener gen3 = new  Gener("G3","Horror");
            Gener gen4 = new Gener("G4","Comedy");
            
            
            
           
            int choice;
            System.out.println("------------------------------WELCOME TO THE GLOBAL MOVIES...------------------------------");  
            System.out.println("Enter 1 to LOG IN as a USER");  
            System.out.println("Enter 2 to LOG IN as a ADMIN");  
            System.out.println("Enter 3 to SIGN UP as a USER"); 
            System.out.println("Enter Your Choice :-");
            
            choice = reader.nextInt();
            
            if (choice == 1) {  
                System.out.println("----------------LOG IN as a USER---------------");
                int  U_ID;
                String U_Name;
                String U_Email;
                String U_Pass;
                
                System.out.println("Enter User Name : ");
                U_Name = reader.next();
                System.out.println("Enter User Password : ");
                U_Pass = reader.next();
                
                boolean check1 =userEao.uvalidate(U_Name, U_Pass);
                
                int choicenew;
                
                System.out.println("Enter 1 to View the all Movies"); 
                System.out.println("Enter 2 to View the all Geners"); 
                System.out.println("Enter 3 to Purchase the Movies ");  
                System.out.println("Enter 4 to Review the Movies"); 
                System.out.println("Enter Your Choice :-");
                choicenew=reader.nextInt();
                
                
                
                if (choicenew == 1) {  
                    System.out.println("----------------VIEW ALL MOVIE LIST--------------");
                
                      Movie mov = new Movie();
                      List<Movie> movies = movEao.getAllMovie(mov);
                      for (Movie m : movies) {
                        System.out.println("Movie ID   :- "+ m.getM_ID() + " ||| " + "Movie Name   :- "+ m.getM_Name() + " ||| " + " Movie Actors   :- " + m.getM_Actors() + " ||| " + " Movie Directors   :- " + m.getM_Directors()  +" Movie Run Time   :- " + m.getM_Runtime()+ " ||| ");
                      }
                      
                     }
                System.out.println(" ");
                System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
               
                if (choicenew == 2) {
                    System.out.println("----------------VIEW ALL MOVIE LIST--------------");
                             Gener gener = new Gener();
                             List<Gener> geners = generEao.getAllGener(gener);
                             for (Gener g : geners) {
                                    System.out.println("Gener ID   :- "+ g.getG_ID()+ " ||| " + "Gener Type   :- "+ g.getG_Type() + " ||| ");
                      
                    
                   
                    
                }
                          System.out.println(" ");
                    System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                   
                }
                
            
                if (choicenew == 3) {  
                    System.out.println("--------------------------PURCHASE THE MOVIE------------------------");
                
               
                String M_ID;
                
                System.out.println("Enter User ID : ");
                U_ID =reader.nextInt();
                System.out.println("Enter Move ID : ");
                M_ID = reader.next();
                movEao.buyMovie(M_ID, U_ID);
                
                System.out.println(" ");
                    System.out.println("***************************************Thank you ....You purchase the movie...***************************************");
                
                
                System.out.println(" ");
                    System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
               
               
                }
                 if (choicenew == 4) {  
                    int u_id;
                    String review;
                    int rating;
                   
                    System.out.println("--------------------------REVIEW THE MOVIE-------------------------");
                    String m_id;
                    System.out.println("Enter User ID :");  
                    u_id = reader.nextInt();
                    System.out.println("Enter Movie ID "); 
                    m_id = reader.next();
                    System.out.println("Enter Your Review :");
                    review = reader.next();
                    System.out.println("Enter Movie Rating 1- 10 :");
                    rating = reader.nextInt();
                    Review newRate = new Review(rating, review);
                    reviewEao.createReview(newRate,u_id,m_id);
                    
                    System.out.println(" ");
                    System.out.println("***************************************THANK YOU FOR YOUR REVIEW***************************************");
                    System.out.println(" ");
                    System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                
                
                    
                    
                    
                    
                
                
                
                
              
                
                
           
                
                
            
          }
            }
            if (choice == 2) {
                
//                generEao.create(gen1);
//                generEao.create(gen2);
//                generEao.create(gen3);
//                generEao.create(gen4);
                
                System.out.println("---------------LOG IN as a ADMIN---------------");  
                String Ad_ID;
                String Ad_Name;
                String Ad_PW;
            
                System.out.println("");
                
                System.out.println("Enter Admin ID : ");
                Ad_ID = reader.next(); 
                System.out.println("Enter Admin Password: ");  
                Ad_PW = reader.next(); 
                
                
                
                
                if (("Ad1".equals(Ad_ID)&& "udani".equals(Ad_PW)) || ("Ad2".equals(Ad_ID)&&"chethana".equals(Ad_PW)) ){
                System.out.println("Admin Successfully logged.....!!!");

                    if("Ad1".equals(Ad_ID)&& "udani".equals(Ad_PW)){
                    int AD1choice;
                    System.out.println("Enter 1 to ADD A NEW MOVIE"); 
                    System.out.println("Enter 2 to VIEW MOVIE LIST");
                    System.out.println("Enter 3 to VIEW USER LIST");
                    System.out.println("Enter 4 to VIEW ALL MOVIES Got By USERS LIST");
                    AD1choice = reader.nextInt();
                
                        if(AD1choice == 1){
                          System.out.println("---------------INSERT A NEW MOVIE---------------");
                          String M_ID;
                          String M_Name;
                          String M_Actors;
                          String M_Directors;
                          int M_Runtime;
                    
                          System.out.println("Enter Movie ID: **************TYPE WITHOUT SPACE**************** ");  
                          M_ID = reader.next();
            
                          System.out.println("Enter Movie Name: **************TYPE WITHOUT SPACE**************** ");  
                          M_Name = reader.next();  
                    
                          System.out.println("Enter Actors: **************TYPE WITHOUT SPACE****************  ");  
                          M_Actors = reader.next(); 
                    
                          System.out.println("Enter Directors: **************TYPE WITHOUT SPACE****************  ");  
                          M_Directors = reader.next(); 
                    
                          System.out.println("Enter Run Time: **************TYPE WITHOUT SPACE**************** ");  
                          M_Runtime = reader.nextInt();  
                    
                          Movie movie = new Movie(M_ID, M_Name, M_Actors, M_Directors, M_Runtime);
                          movie.setAdmin(ad1);
                    
                          movEao.saveOrUpdate(movie);
                          //Enter Geners
                          System.out.println("Enter Geners: ");  
                          
                          String mov_gens = reader.next();
 
                          Gener g = generEao.getGenre(mov_gens);
          
                          movie.getGeners().add(g);
                          movEao.saveOrUpdate(movie);
                          
                          System.out.println(" ");
                          System.out.println("***************************************ADDING THE MOVIE IS SUCCESS***************************************");
                          System.out.println(" ");
                          System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                
                
                    
                }
                        if(AD1choice == 2){
                             System.out.println("----------------VIEW ALL MOVIE LIST--------------");
                             Movie mov = new Movie();
                             List<Movie> movies = movEao.getAllMovie(mov);
                             for (Movie m : movies) {
                                    System.out.println("Movie ID   :- "+ m.getM_ID() + " ||| " + "Movie Name   :- "+ m.getM_Name() + " ||| " + " Movie Actors   :- " + m.getM_Actors() + " ||| " + " Movie Directors   :- " + m.getM_Directors()  +" Movie Run Time   :- " + m.getM_Runtime()+ " ||| ");
                      }
                      System.out.println(" ");
                          System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
               
                        }
                        
                      if(AD1choice == 3){
                             System.out.println("----------------VIEW ALL USER LIST--------------");
                             User user = new User();
                             List<User> users = userEao.getAllUser(user);
                             for (User  u : users) {
                                    System.out.println("User ID   :- "+ u.getU_ID()+ " ||| " + "User Name   :- "+ u.getU_Name()+ " ||| " + " User Email   :- " + u.getU_Email() + " ||| " );
                      }
                          System.out.println(" ");
                          System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
               
                      }
                      
                      if(AD1choice == 4){
                         System.out.println("----------------VIEW ALL MOVIES Got By USERS LIST--------------");
                             
                          int uid;
                      
                          System.out.println("Insert User Id   : ");
                          uid= reader .nextInt();
                          movEao.getMoviesByUser(uid);
                      
                          System.out.println(" ");
                          System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
               
    
                }
                    }
                    else{
                System.out.println("Invalid User ID ...Try Again!!!");  
                }}
                if("Ad2".equals(Ad_ID)&&"chethana".equals(Ad_PW)){
                    
                    
                int AD2choice;
                System.out.println("Enter 1 to DELETE A MOVIE"); 
                System.out.println("Enter 2 to VIEW MOVIE LIST");
                System.out.println("Enter 3 to VIEW USER LIST");
                AD2choice = reader.nextInt();
                
                if(AD2choice == 1){
                   System.out.println("Enter Movie ID: ");
                   String MID = reader.next(); 
                  
                   Movie mv= movEao.getMovie(MID);
                   movEao.delete(mv);
                   
                   
                   
                }
                if(AD2choice == 2){
                             System.out.println("----------------VIEW ALL MOVIE LIST--------------");
                             Movie mov = new Movie();
                             List<Movie> movies = movEao.getAllMovie(mov);
                             for (Movie m : movies) {
                                    System.out.println("Movie ID   :- "+ m.getM_ID() + " ||| " + "Movie Name   :- "+ m.getM_Name() + " ||| " + " Movie Actors   :- " + m.getM_Actors() + " ||| " + " Movie Directors   :- " + m.getM_Directors()  +" Movie Run Time   :- " + m.getM_Runtime()+ " ||| ");
                      }
                         System.out.println(" ");
                         System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                
                }
                if(AD2choice == 3){
                             System.out.println("----------------VIEW ALL USER LIST--------------");
                             User user = new User();
                             List<User> users = userEao.getAllUser(user);
                             for (User  u : users) {
                                    System.out.println("User ID   :- "+ u.getU_ID()+ " ||| " + "User Name   :- "+ u.getU_Name()+ " ||| " + " User Email   :- " + u.getU_Email() + " ||| " );
                      }
                         System.out.println(" ");
                         System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                
            }
            
            } 
            
                    }
                    
            if (choice == 3) {  
            System.out.println("---------------Register as a USER---------------"); 
            System.out.println("Enter your Name: **************TYPE WITHOUT SPACE**************** ");  
            String U_Name1 = reader.next(); 
            
            System.out.println("Enter your Email: **************TYPE WITHOUT SPACE**************** ");  
            String U_Email1 = reader.next(); 
            
            System.out.println("Enter your Password: **************TYPE WITHOUT SPACE**************** ");  
            String U_Pass1 = reader.next(); 
            
            User user = new User(U_Name1,U_Email1,U_Pass1);
            userEao.create(user);
            
            System.out.println("You're successfully registered!!"); 
            System.out.println(" ");
            System.out.println("***************************************RERUN THE CODE FOR YOUR NEXT REQUIREMENT***************************************");
                
            
           
            }  
            
//         return false;
 
        }
 
}

    



    







                
            
            
                
            
            
  