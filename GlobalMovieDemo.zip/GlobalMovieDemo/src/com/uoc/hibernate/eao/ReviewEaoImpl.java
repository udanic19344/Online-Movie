/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.Review;
import com.uoc.hibernate.entity.User;
import com.uoc.hibernate.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Admin
 */
public class ReviewEaoImpl implements ReviewEao{
    SessionFactory sessionFactory;

    public ReviewEaoImpl() {
        sessionFactory = HibernateUtil.getSessFactory();
        
    }

    @Override
    public void createReview(Review rate, int U_ID, String M_ID) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        User userObj = (User) session.get(User.class,U_ID );
        Movie movieObj = (Movie) session.get(Movie.class,M_ID );
        session.save(rate);
        rate.setUser(userObj);
        rate.setMovie(movieObj);
       
        
        session.getTransaction().commit();
        session.close();
    }

    

  
        
    
    
    
    
    
}
