/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Gener;
import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.util.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Admin
 */
public class GenerEaoImpl implements GenerEao{
    SessionFactory sessionFactory;

    public GenerEaoImpl() {
        sessionFactory =HibernateUtil.getSessFactory();
        
    }

    @Override
    public void create(Gener gen) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        session.persist(gen);
        
        session.getTransaction().commit();
        session.close();
    
    }

    @Override
    public void saveOrUpdate(Gener gen) {
        
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        session.saveOrUpdate(gen);
        
        session.getTransaction().commit();
        session.close();
    
    }

    @Override
    public Gener getGenre(String G_ID) {
        
        
        Session session = sessionFactory.openSession();
        Gener gener = (Gener) session.get(Gener.class, G_ID);
        
       
    session.close(); 
    return gener; 
    
    }

    @Override
    public List<Gener> getAllGener(Gener gen) {
        String hql = "FROM Gener"; 
        Session session = sessionFactory.openSession(); 
//        Movie movie = (Movie) session.get(Movie.class, mov); 
        
        org.hibernate.Query query = session.createQuery(hql); 
//        query.setParameter("department_id", departmentId); 
        
        List<Gener> geners = query.list(); 
        
        session.close();
        
        return geners; 
    
    }
    
    
    
}
