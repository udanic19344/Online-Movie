/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.entity;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "GMDB_REVIEW_TABLE")
public class Review implements Serializable {
    private int R_ID;
    private  int R_User_Rating;
    private String R_User_Description;

    private Movie movie;
    private User user;

    public Review() {
    }

    public Review(int R_User_Rating, String R_User_Description) {
        this.R_User_Rating = R_User_Rating;
        this.R_User_Description = R_User_Description;
    }

    public void setR_ID(int R_ID) {
        this.R_ID = R_ID;
    }

    public void setR_User_Rating(int R_User_Rating) {
        this.R_User_Rating = R_User_Rating;
    }

    public void setR_User_Description(String R_User_Description) {
        this.R_User_Description = R_User_Description;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int getR_ID() {
        return R_ID;
    }

    public String getR_User_Description() {
        return R_User_Description;
    }
    
   

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "M_ID")
    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "U_ID")
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
    
    
    
}
