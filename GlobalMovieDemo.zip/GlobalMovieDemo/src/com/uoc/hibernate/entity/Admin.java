/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "GMDB_ADMIN_TABLE")
public class Admin implements Serializable {
    private String Ad_ID;
    private String Ad_Name;
    private String Ad_PW;

    private List<Movie> movies;
    
    public Admin() {
    }

    public Admin(String Ad_ID, String Ad_Name, String Ad_PW) {
        this.Ad_ID = Ad_ID;
        this.Ad_Name = Ad_Name;
        this.Ad_PW = Ad_PW;
    }

    @Id
    public String getAd_ID() {
        return Ad_ID;
    }

    public void setAd_ID(String Ad_ID) {
        this.Ad_ID = Ad_ID;
    }

    public String getAd_Name() {
        return Ad_Name;
    }

    public void setAd_Name(String Ad_Name) {
        this.Ad_Name = Ad_Name;
    }

    public String getAd_PW() {
        return Ad_PW;
    }

    public void setAd_PW(String Ad_PW) {
        this.Ad_PW = Ad_PW;
    }

    @OneToMany(mappedBy = "admin")
    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }
    
    
    
    
}
