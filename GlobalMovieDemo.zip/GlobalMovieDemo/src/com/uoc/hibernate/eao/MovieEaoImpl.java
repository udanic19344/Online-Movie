/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.eao;

import com.uoc.hibernate.entity.Movie;
import com.uoc.hibernate.entity.Review;
import com.uoc.hibernate.entity.User;
import com.uoc.hibernate.util.HibernateUtil;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author Admin
 */
public class MovieEaoImpl implements MovieEao{
    SessionFactory sessionFactory;

    public MovieEaoImpl() {
        sessionFactory = HibernateUtil.getSessFactory();
        
       
    }
    
    

    @Override
    public void crete(Movie mov) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        session.persist(mov);
        
        session.getTransaction().commit();
        session.close();
        
    
    }

    @Override
    public void saveOrUpdate(Movie mov) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        session.saveOrUpdate(mov);
        
        session.getTransaction().commit();
        session.close();
        
        
    
    }

    @Override
    public Movie getMovie(String M_ID) {
        Session session = sessionFactory.openSession();
        Movie movie = (Movie) session.get(Movie.class, M_ID);
        List<User> users = movie.getUsers();
        
    session.close();
    return movie;
    
    }

    
    @Override
    public void delete(Movie mv) {
        
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        session.delete(mv);
 
        session.getTransaction().commit();
        session.close();
        
        
               
        
    }

    @Override
    public List<Movie> getAllMovie(Movie mov) {
           String hql = "FROM Movie"; 
        Session session = sessionFactory.openSession(); 
//        Movie movie = (Movie) session.get(Movie.class, mov); 
        
        org.hibernate.Query query = session.createQuery(hql); 
//        query.setParameter("department_id", departmentId); 
        
        List<Movie> movies = query.list(); 
        
        session.close();
        
        return movies; 
    
    
    }

    @Override
    public void buyMovie(String M_ID, int U_ID) {
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        
        User userObj = (User) session.get(User.class,U_ID );
        Movie movieObj= (Movie) session.get(Movie.class,M_ID);
//        List<movie> movies = userObj.getMovies();
//        List<user> users = movieObj.getUsers();
        //user u11 = new user();
       
//        u11.getMovies().add(mov2);
//        mov2.getUsers().add(u11);
//        userObj.getMovies().add(movieObj);
        movieObj.getUsers().add(userObj);


        session.getTransaction().commit();
        session.close();
        
    
    }

    @Override
    public List<Movie> getMoviesByUser(int U_ID) {
         List<Movie> movieList = null;
        Session session = sessionFactory.openSession();
//        session.beginTransaction();
//        String hql = "FROM user u JOIN u.movie WHERE u.movies = :mId";
//        Query query = session.createQuery(hql);
//        query.setParameter("mId", mId);
//        userList = query.list();
//        session.close();
//        return userList;
           
          User mu = (User) session.get(User.class, U_ID);
          movieList = mu.getMovies();
          for(Movie m:movieList){
              System.out.println(m.getM_ID()+" "+ m.getM_Name());
          }
          session.close();
          return movieList;
    
    }

   
        
    

    
    
}
