/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.uoc.hibernate.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "GMDB_GENRE_TABLE")
public class Gener implements Serializable{
    private  String G_ID;
    private  String G_Type;
    
    private List<Movie> movies = new ArrayList<>();

    public Gener() {
    }

    public Gener(String G_ID, String G_Type) {
        this.G_ID = G_ID;
        this.G_Type = G_Type;
    }

    @Id
    public String getG_ID() {
        return G_ID;
    }

    public void setG_ID(String G_ID) {
        this.G_ID = G_ID;
    }

    public String getG_Type() {
        return G_Type;
    }

    public void setG_Type(String G_Type) {
        this.G_Type = G_Type;
    }

    @ManyToMany(cascade = CascadeType.ALL)
     @JoinTable(name = "GMDB_MOVIE_GENRE_TABLE",
               joinColumns = {@JoinColumn(name = "G_ID")},
               inverseJoinColumns = {@JoinColumn(name = "M_ID")})
    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }
    
    
    
}
